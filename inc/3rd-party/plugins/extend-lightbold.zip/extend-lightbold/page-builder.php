<?php
add_filter('the_content', 'perf_page_builder');
function perf_page_builder($content) {

	if( !is_page() || !function_exists('have_rows') ) { return $content; }
        
    $new_content = '';

    if( have_rows('light_bold_page_builder') ):
        
        $new_content .= '<section id="lightbold_page_builder" class="">';

        while ( have_rows('light_bold_page_builder') ) : the_row();

            if( get_row_layout() == 'full_width' ):

                $new_content .= '<div class="col-12 builder-col break-word">';
                    $new_content .= get_sub_field('col_1_1');
                $new_content .= '</div>';

            elseif( get_row_layout() == 'one_half' ): 

                $new_content .= '<div class="lg-flex mxn2">';

                    $new_content .= '<div class="lg-col-6 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_2_1');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-6 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_2_2');
                    $new_content .= '</div>';

                $new_content .= '</div>';
            
            elseif( get_row_layout() == 'one_third' ): 
                
                $new_content .= '<div class="lg-flex mxn2">';

                    $new_content .= '<div class="lg-col-4 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_3_1');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-4 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_3_2');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-4 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_3_3');
                    $new_content .= '</div>';

                $new_content .= '</div>';

            elseif( get_row_layout() == 'one_fourth' ): 
                
                $new_content .= '<div class="lg-flex mxn2">';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_4_1');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_4_2');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_4_3');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_4_4');
                    $new_content .= '</div>';

                $new_content .= '</div>';

            elseif( get_row_layout() == 'one_fourth_three_fourth' ): 
                
                $new_content .= '<div class="lg-flex mxn2 mb2">';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_5_1');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-9 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_5_2');
                    $new_content .= '</div>';

                $new_content .= '</div>';

            elseif( get_row_layout() == 'three_fourth_one_fourth' ): 
                
                $new_content .= '<div class="lg-flex mxn2">';

                    $new_content .= '<div class="lg-col-9 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_6_1');
                    $new_content .= '</div>';

                    $new_content .= '<div class="lg-col-3 px2 builder-col break-word">';
                        $new_content .= get_sub_field('col_6_2');
                    $new_content .= '</div>';

                $new_content .= '</div>';
            endif;

        endwhile;

        $new_content .= '</section>';

    endif;

    $content .= $new_content;	
	
	return $content;
}
    
