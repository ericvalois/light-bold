<?php
/*
* Create option pages
*/
if( function_exists('acf_add_options_page') ) {

    acf_add_options_sub_page(array(
		'page_title' 	=> 'General',
		'menu_title'	=> 'General',
		'parent_slug'	=> 'light-bold-main-page',
    ));
    
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Style',
		'menu_title'	=> 'Style',
		'parent_slug'	=> 'light-bold-main-page',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Performance',
		'menu_title'	=> 'Performance',
		'parent_slug'	=> 'light-bold-main-page',
	));
}

/*
* Layout three colouns
*/
add_filter('acf/load_field/key=field_57d95e15a9b7c', 'perf_three_layout_options');
function perf_three_layout_options( $field ) {
	$field['choices'] = array(
	    "1" => '<img title="Full width" width="150" src="' . plugins_url( '/images/one-column.png', __FILE__ ) . '">',
	    "2" => '<img title="Two columns" width="150" src="' . plugins_url( '/images/two-columns.png', __FILE__ ) . '">',
	    "3" => '<img title="Three columns" width="150" src="' . plugins_url( '/images/three-columns.png', __FILE__ ) . '">',
	);

    return $field;
}

// Layout four colouns
add_filter('acf/load_field/key=field_599c4a4fdcce4', 'perf_four_layout_options');
add_filter('acf/load_field/key=field_57d05562c6d38', 'perf_four_layout_options');
function perf_four_layout_options( $field ) {
	$field['choices'] = array(
	    "1" => '<img title="Full width" width="150" src="' . plugins_url( '/images/one-column.png', __FILE__ ) . '">',
	    "2" => '<img title="Two columns" width="150" src="' . plugins_url( '/images/two-columns.png', __FILE__ ) . '">',
	    "3" => '<img title="Three columns" width="150" src="' . plugins_url( '/images/three-columns.png', __FILE__ ) . '">',
        "4" => '<img title="Four columns" width="150" src="' . plugins_url( '/images/four-columns.png', __FILE__ ) . '">',
	);

    return $field;
}

// Sidebar layouts
add_filter('acf/load_field/key=field_59df933c7c8ff', 'perf_sidebar_layout_options');
function perf_sidebar_layout_options( $field ) {
	$field['choices'] = array(
	    "1" => '<img title="Sidebar left" width="150" src="' . plugins_url( '/images/sidebar-left.png', __FILE__ ) . '">',
	    "2" => '<img title="Sidebar right" width="150" src="' . plugins_url( '/images/sidebar-right.png', __FILE__ ) . '">',
	);

    return $field;
}

// Menu layouts
add_filter('acf/load_field/key=field_5a4e2428b038a', 'perf_menu_layout_options');
function perf_menu_layout_options( $field ) {
	$field['choices'] = array(
	    "side" => '<img title="Side Menu" width="150" src="' . plugins_url( '/images/side-menu.png', __FILE__ ) . '">',
	    "top" => '<img title="Top Menu" width="150" src="' . plugins_url( '/images/top-menu.png', __FILE__ ) . '">',
	);

    return $field;
}

/**
 * Show ACF options if the user want to
 */
if( !perf_get_field("perf_show_acf","option") ){
	add_filter('acf/settings/show_admin', '__return_false');
}


/*
* Add custom css for ACF
*/
add_action('admin_head', 'perf_my_custom_acf_style');
function perf_my_custom_acf_style() {
?>
<style>
    .acf-image-select label input {
	    display: none;
	}
	.acf-image-select label p {
	    margin: 0;
	    font-weight: bold;
	    text-align: center;
	}
	.acf-image-select label img {
	    -webkit-transition: all 0.30s ease-in-out;
		-moz-transition: all 0.30s ease-in-out;
		-ms-transition: all 0.30s ease-in-out;
		-o-transition: all 0.30s ease-in-out;
		outline: none;
        padding: 0.5em;
        border: 2px dashed #ccc;
	}
	.acf-image-select label.selected img {
		//border: 6px solid #DDDDDD;
        border: 2px dashed #666;
        background-color: #f7f7f7;
        box-shadow: 0 0 3px rgba(0,0,0,0.1);
	}

	.acf-title{
		font-size: 20px;
		padding: 15px;
		color: #eee;
		background-color: #23282d;
		font-weight: 400;
		line-height: 1;
	}

    .acf-flexible-content .layout .acf-fc-layout-handle{
        background-color: #333 !important;
        color: #fff !important;
    }

    .acf-flexible-content .layout{
        border-color: #333 !important;
    }

  </style>
<?php
}