<?php
/*
* Inline styles
*/
add_action( 'light_bold_head_open', 'perf_inline_styles', 10 );
function perf_inline_styles() {

    echo '<style>';

        do_action( 'light_bold_mobile_styles' );

        echo '@media (min-width: 40em)  {';
            do_action( 'light_bold_sm_styles' );
        echo '}';

        echo '@media (min-width: 52em)  {';
            do_action( 'light_bold_md_styles' );
        echo '}';

        echo '@media (min-width: 64em)  {';
            do_action( 'light_bold_lg_styles' );
        echo '}';

        echo '@media (min-width: 1200px)  {';
            do_action( 'light_bold_1200_styles' );
        echo '}';

        echo '@media (min-width: 1650px)  {';
            do_action( 'light_bold_96em_styles' );
        echo '}';

    echo '</style>';
}

/**
 * Print custom inline CSS in the head
 */
add_action('light_bold_mobile_styles','perf_e_custom_styles', 5);
function perf_e_custom_styles(){
    $custom_styles = light_bold_custom_styles();
    echo light_bold_compress( $custom_styles );
}