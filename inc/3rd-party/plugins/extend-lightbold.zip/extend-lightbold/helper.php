<?php
/*
* Custom ACF function
*/
if( !function_exists("perf_get_field") ){
    function perf_get_field($field_name, $post_id = false, $format_value = true){
        if( function_exists("get_field") ){
            return get_field($field_name, $post_id, $format_value);
        }else{
            return false;
        }
    }
}

// SImple detection function
function extend_light_bold_exist(){
    return true;
}

function perf_on_page_css_optimisation(){
    
    global $post;

    if( is_object( $post ) ){
        $on_page_css_optimisation_disabled = perf_get_field('perf_on_page_css_optimisation_disabled', $post->ID);
    }else{
        $on_page_css_optimisation_disabled = false;  
    }

    return $on_page_css_optimisation_disabled;
}

function perf_on_page_js_optimisation(){

    global $post;

    if( is_object( $post ) ){
        $on_page_js_optimisation_disabled = perf_get_field('perf_on_page_js_optimisation_disabled', $post->ID);
    }else{
        $on_page_js_optimisation_disabled = false;
    }

    return $on_page_js_optimisation_disabled;
}

/**
* Gets scripts registered and enqueued.
*
* @return array(_WP_Dependency) A list of enqueued dependencies
*/
function get_enqueued_scripts() {
    global $wp_scripts;
    $enqueued_scripts = array();
    foreach ( $wp_scripts->queue as $handle ) {
        $enqueued_scripts[] = $wp_scripts->registered[ $handle ];
    }
    return $enqueued_scripts;
}

/**
* Gets a script dependency for a handle
*
* @param string $handle The handle
* @return _WP_Dependency associated with input handle
*/
function get_dep_for_handle( $handle ) {
    global $wp_scripts;
    return $wp_scripts->registered[ $handle ];
}

/**
* Gets the source URL given a script handle.
*
* @param string $handle The handle
* @return URL associated with handle, or empty string
*/
function get_src_for_handle( $handle ) {
    $dep = get_dep_for_handle( $handle );
    $suffix = ( $dep->src && $dep->ver )
        ? "?ver={$dep->ver}"
        : '';
    return "{$dep->src}{$suffix}";
}

/**
* Gets all dependencies for a given handle.
*
* @param string $handle The handle
*/
function get_deps_for_handle( $handle ) {
    $dep = get_dep_for_handle( $handle );
    return $dep->deps;
}

/**
* Generate the social share markups.
*
* @return string
*/
function perf_get_social_share( $title = "" ){
    $shares = '<section class="clearfix light-bold-social-share block hide-print">';

        if( !empty( $title ) ){
            $shares .= '<h5 class="mb1 mt2">' . esc_html( $title ) . '</h5>';
        }
        
        $shares .= '<div id="social_widget" class="clearfix mb2">';
            $shares .= '<div class="left mb1 mr1">';
                $shares .= '<a target="_blank" href="http://www.facebook.com/sharer.php?u=' . get_permalink() . '&t=' . urlencode( get_the_title() ) . '" class="flex flex-center social_share align-middle"><svg class="mx-auto fa fa-facebook"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-facebook"></use></svg></a>';
            $shares .= '</div>';

            $shares .= '<div class="left mb1 mr1">';
                $shares .= '<a target="_blank" href="http://twitter.com/home?status=' . urlencode( get_the_title() ) . '+' . get_permalink() . '" class="flex flex-center  social_share"><svg class="mx-auto fa fa-twitter"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-twitter"></use></svg></a>';
            $shares .= '</div>';

            $shares .= '<div class="left mb1 mr1">';
                $shares .= '<a target="_blank" href="https://plus.google.com/share?url=' . get_permalink() . '" class="flex flex-center social_share"><svg class="mx-auto fa fa-google-plus"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-google-plus"></use></svg></a>';
            $shares .= '</div>';

            $shares .= '<div class="left mb1 mr1">';
                $shares .= '<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=' . get_permalink() . '&title=' . urlencode( get_the_title() ) . '" class="flex flex-center  social_share"><svg class="mx-auto fa fa-linkedin"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-linkedin"></use></svg></a>';
            $shares .= '</div>';

            $shares .= '<div class="left mr1">';
                $pinterest_link = "javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());";
                $shares .= '<a target="_blank" href="'. $pinterest_link .'" class="flex flex-center  social_share"><svg class="mx-auto fa fa-pinterest"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-pinterest"></use></svg></a>';
            $shares .= '</div>';
        $shares .= '</div>';
    $shares .= '</section>';

    return $shares;
}