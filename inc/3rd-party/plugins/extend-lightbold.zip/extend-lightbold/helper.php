<?php
/*
* Custom ACF function
*/
if( !function_exists("perf_get_field") ){
    function perf_get_field($field_name, $post_id = false, $format_value = true){
        if( function_exists("get_field") ){
            return get_field($field_name, $post_id, $format_value);
        }else{
            return false;
        }
    }
}

// SImple detection function
function extend_light_bold_exist(){
    return true;
}