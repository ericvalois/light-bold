<?php
/*
* Custom ACF function
*/
if( !function_exists("perf_get_field") ){
    function perf_get_field($field_name, $post_id = false, $format_value = true){
        if( function_exists("get_field") ){
            return get_field($field_name, $post_id, $format_value);
        }else{
            return false;
        }
    }
}

// SImple detection function
function extend_light_bold_exist(){
    return true;
}

function perf_on_page_css_optimisation(){
    
        global $post;
    
        if( is_object( $post ) ){
            $on_page_css_optimisation_disabled = perf_get_field('perf_on_page_css_optimisation_disabled', $post->ID);
        }else{
            $on_page_css_optimisation_disabled = false;  
        }
    
        return $on_page_css_optimisation_disabled;
    }
    
    function perf_on_page_js_optimisation(){
    
        global $post;
    
        if( is_object( $post ) ){
            $on_page_js_optimisation_disabled = perf_get_field('perf_on_page_js_optimisation_disabled', $post->ID);
        }else{
            $on_page_js_optimisation_disabled = false;
        }
    
        return $on_page_js_optimisation_disabled;
    }
    
    /**
    * Gets scripts registered and enqueued.
    *
    * @return array(_WP_Dependency) A list of enqueued dependencies
    */
    function get_enqueued_scripts() {
        global $wp_scripts;
        $enqueued_scripts = array();
        foreach ( $wp_scripts->queue as $handle ) {
            $enqueued_scripts[] = $wp_scripts->registered[ $handle ];
        }
        return $enqueued_scripts;
    }
    
    /**
    * Gets a script dependency for a handle
    *
    * @param string $handle The handle
    * @return _WP_Dependency associated with input handle
    */
    function get_dep_for_handle( $handle ) {
        global $wp_scripts;
        return $wp_scripts->registered[ $handle ];
    }
    
    /**
    * Gets the source URL given a script handle.
    *
    * @param string $handle The handle
    * @return URL associated with handle, or empty string
    */
    function get_src_for_handle( $handle ) {
        $dep = get_dep_for_handle( $handle );
        $suffix = ( $dep->src && $dep->ver )
            ? "?ver={$dep->ver}"
            : '';
        return "{$dep->src}{$suffix}";
    }
    
    /**
    * Gets all dependencies for a given handle.
    *
    * @param string $handle The handle
    */
    function get_deps_for_handle( $handle ) {
        $dep = get_dep_for_handle( $handle );
        return $dep->deps;
    }