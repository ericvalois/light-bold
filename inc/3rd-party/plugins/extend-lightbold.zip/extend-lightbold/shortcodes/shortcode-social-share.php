<?php
/**
 * Create Social Share shortcode
 */
add_shortcode( 'light-bold-share', 'perf_social_share_shortcode' );
function perf_social_share_shortcode( $attrs ) {

    $a = shortcode_atts( array(
        'title' => '',
    ), $attrs );

    $shares = perf_get_social_share( $a['title'] );

    return $shares;
}
