# Extend Light & Bold
Extend the functionalities of Light & Bold Theme 
