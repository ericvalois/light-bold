<?php
/**
 * Icons Shorcode init
 */
add_action( 'init', 'light_bold_icons_shortcodes');
function light_bold_icons_shortcodes(){
    add_shortcode('lightbold-icons', 'light_bold_icons_shortcodes_callback');
}

/**
 * Icons Shorcode Callback
 */
function light_bold_icons_shortcodes_callback($atts){
    extract(shortcode_atts(array(
        'icon' => "",
        'class' => "",
        'circle' => "circle-no",
        'iconcolor'      => "",
        'circlecolor'      => "",
        'alignment'      => "",
        'id'      => "",
        'size'      => "",
        'circlebordercolor' => "transparent",
    ), $atts));

    $icon_class = "";
    $style = "";

    if( $circle == "yes" ){ $icon_class .= "circle-yes "; }
    if( !empty( $size ) ){ 
        if( $size == "xl" ){
            $icon_class .= "xl-icon ";
        }elseif( $size == "large" ){
            $icon_class .= "large-icon ";
        }elseif( $size == "medium" ){
            $icon_class .= "medium-icon ";
        }elseif( $size == "small" ){
            $icon_class .= "small-icon ";
        }
    }
    if( !empty( $alignment ) ){
        if( $alignment == "left" ){
            $icon_class .= "left mr1 ";
        }elseif( $alignment == "right" ){
            $icon_class .= "right ml1 ";
        }elseif( $alignment == "center" ){
            $icon_class .= "mx-auto ";
        }
    }
    
    $icon_class .= $class;

    if( !empty( $iconcolor ) ){ $style .= 'color:'.$iconcolor.';'; }
    if( !empty( $circlebordercolor ) ){ $style .= 'border-color:'.$circlebordercolor.';'; }
    if( !empty( $circlecolor ) ){ $style .= 'background-color:'.$circlecolor.';'; }

    $return_string = '<span style="'.$style.'" class="'. $icon_class .'"><svg class="fa '.$icon.'"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#'.$icon.'"></use></svg></span>';

    return $return_string;
}

/**
 * cta box Shorcode init
 */
add_action( 'init', 'light_bold_box_cta_shortcodes');
function light_bold_box_cta_shortcodes(){
    add_shortcode('lightbold-cta', 'light_bold_box_cta_shortcodes_callback');
}

/**
 * Icons Shorcode Callback
 */
function light_bold_box_cta_shortcodes_callback($atts){
    extract(shortcode_atts(array(
        'title' => "",
        'description' => "",
        'link_label' => "",
        'link_target'      => "",
        'class' => "",
    ), $atts));

    $class = "";


    $return_string = '<div class="box_cta p2 main-color mb2">';
    if( !empty( $title ) ){
        $return_string .= '<h5 class="mt0 regular">'.$title.'</h5>';
    }
    if( !empty( $link_label ) && !empty( $link_target ) ){
        $return_string .= '<a class="perf_btn sm-col-right sm-ml2 mb1 sm-mb0 regular" href="'.$link_target.'">'.$link_label.'</a>';
    }
    if( !empty( $description ) ){
        $return_string .= '<p class="mt0">'.$description.'</p>';
    }
    $return_string .= '</div>';
    

    return $return_string;
}