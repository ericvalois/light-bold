<?php
/*
 *  Plugin Name:       Extend Light & Bold 
 *  Plugin URI:        https://github.com/perfthemes/perf-lightbold-extend
 *  Description:       Simple plugin to extend Light & Bold theme
 *  Version:           1.0.2
 *  Author:            Perfthemes
 *  Author URI:        https://perfthemes.com/
 *  Text Domain:       perf
 *  Domain Path:       /languages
 */

/**
 * Helper functions
 */
require 'helper.php';

/**
 * Lazy Load
 */
require 'lazyload.php';

/**
 * Load ACF options pages and minor behavior fix
 */
require 'acf-extra.php';

/**
 * Load ACF Meta box
 */
require 'acf-meta-box.php';

/**
 * WordPress cleanup
 */
require 'clean.php';


function perf_on_page_css_optimisation(){

    global $post;

    if( is_object( $post ) ){
        $on_page_css_optimisation_disabled = perf_get_field('perf_on_page_css_optimisation_disabled', $post->ID);
    }else{
        $on_page_css_optimisation_disabled = false;  
    }

    return $on_page_css_optimisation_disabled;
}

function perf_on_page_js_optimisation(){

    global $post;

    if( is_object( $post ) ){
        $on_page_js_optimisation_disabled = perf_get_field('perf_on_page_js_optimisation_disabled', $post->ID);
    }else{
        $on_page_js_optimisation_disabled = false;
    }

    return $on_page_js_optimisation_disabled;
}

/*
* Async scripts
*/
add_filter( 'script_loader_tag', 'perf_js_optimisation', 10, 2 );
function perf_js_optimisation( $tag, $handle ) {

   $exlude_scripts = array("jquery-core","jquery-migrate","jquery-ui-core","jquery");

    if( !perf_on_page_js_optimisation() && perf_get_field('perf_js_optimisation_active', 'option') && !is_admin() && !in_array($handle,$exlude_scripts) ){
        return str_replace( ' src', ' async src', $tag );    
    }else{
        return $tag;
    }

}


/*
* Move scripts to footer
*/
add_action( 'wp_print_scripts', 'perf_move_js_to_footer' );
function perf_move_js_to_footer() {

    global $wp_scripts;

    $exlude_scripts = array("jquery-core","jquery-migrate","jquery-ui-core","jquery");
    
    foreach( $wp_scripts->queue as $handle ) :
        if( !perf_on_page_js_optimisation() && perf_get_field('perf_js_optimisation_active', 'option') && !is_admin() && !in_array($handle,$exlude_scripts) ){
            $src = $wp_scripts->registered[$handle]->src;
            $deps = $wp_scripts->registered[$handle]->deps;

            wp_deregister_script( $handle );
            wp_dequeue_script( $handle );
            wp_register_script( $handle, $src, $deps, false, true  );
            wp_enqueue_script( $handle );
        }
    endforeach;
    
}


/*
* Inject loadcss scripts to load stylesheet async
* @link https://github.com/filamentgroup/loadCSS
*/
add_filter('wp_footer', 'perf_inject_loadcss_script', 10);
function perf_inject_loadcss_script() {

    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
    ?>
        <script>
            /*! loadCSS. [c]2017 Filament Group, Inc. MIT License */
            !function(a){"use strict";var b=function(b,c,d){function e(a){return h.body?a():void setTimeout(function(){e(a)})}function f(){i.addEventListener&&i.removeEventListener("load",f),i.media=d||"all"}var g,h=a.document,i=h.createElement("link");if(c)g=c;else{var j=(h.body||h.getElementsByTagName("head")[0]).childNodes;g=j[j.length-1]}var k=h.styleSheets;i.rel="stylesheet",i.href=b,i.media="only x",e(function(){g.parentNode.insertBefore(i,c?g:g.nextSibling)});var l=function(a){for(var b=i.href,c=k.length;c--;)if(k[c].href===b)return a();setTimeout(function(){l(a)})};return i.addEventListener&&i.addEventListener("load",f),i.onloadcssdefined=l,l(f),i};"undefined"!=typeof exports?exports.loadCSS=b:a.loadCSS=b}("undefined"!=typeof global?global:this);
            /*! loadCSS rel=preload polyfill. [c]2017 Filament Group, Inc. MIT License */
            !function(a){if(a.loadCSS){var b=loadCSS.relpreload={};if(b.support=function(){try{return a.document.createElement("link").relList.supports("preload")}catch(b){return!1}},b.poly=function(){for(var b=a.document.getElementsByTagName("link"),c=0;c<b.length;c++){var d=b[c];"preload"===d.rel&&"style"===d.getAttribute("as")&&(a.loadCSS(d.href,d,d.getAttribute("media")),d.rel=null)}},!b.support()){b.poly();var c=a.setInterval(b.poly,300);a.addEventListener&&a.addEventListener("load",function(){b.poly(),a.clearInterval(c)}),a.attachEvent&&a.attachEvent("onload",function(){a.clearInterval(c)})}}}(this);
        </script>
        <script></script><!-- Fix IE and Edge bug with loadcss -->
    <?php
    }
}

/*
* Critical CSS
*/
add_action('light_bold_mobile_styles','perf_critical_css', 5);
function perf_critical_css()
{
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_critical_css_active","option") && !is_admin() ){
        echo '/* Critical CSS */ ';

        if( is_page_template("page-templates/template-front.php") ){

            global $post;

            if( light_bold_flickity_detection( $post->ID ) ){
                include_once( "critical/home-with-slider.min.css" );
               
            }else{
                include_once( "critical/home.min.css" );
            }

        }elseif( is_page_template("page-templates/template-contact.php") ){
            include_once( "critical/contact.min.css" );
        }elseif( is_archive() || is_home() || is_search() ){
            include_once( "critical/archive.min.css" );
        }elseif( is_single() ){
            include_once( "critical/single.min.css" );
        }else{
            include_once( "critical/page.min.css" );
        }

        echo '/* End Critical CSS */ ';
    }

}

/*
* Async all stylsheets with loadcss.js
*/
add_filter('light_bold_head_open', 'perf_async_stylsheets', 20); // Inject loadcss.js call for each stylesheets
function perf_async_stylsheets(){
    
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){

        global $wp_styles;

        $queue = $wp_styles->queue;

        foreach( $queue as $stylesheet ){
            if( $stylesheet != "admin-bar" ){
            ?>
                <link rel="preload" href="<?php echo $wp_styles->registered[$stylesheet]->src; ?>" as="style" onload="this.rel='stylesheet'">
                <noscript><link rel="stylesheet" href="<?php echo $wp_styles->registered[$stylesheet]->src; ?>"></noscript>
            <?php
            }
        }
        

    }
}

add_filter('wp_print_styles', 'perf_dequeue_stylesheets', 30); // Dequeue all stylesheets
function perf_dequeue_stylesheets( ) {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        global $wp_styles;
        $queue = $wp_styles->queue;

        foreach( $queue as $handle ){
            if( $handle != "admin-bar" ){
                wp_dequeue_style( $handle );
            }
        }
    }
}

/*
* Preload
*/
add_action( 'light_bold_head_open', 'perf_preload' );
function perf_preload() {
    $active_preload = perf_get_field("perf_preload_active","option");
    

    $perf_image_id = light_bold_select_hero_image();
    $perf_image_src_sm = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-sm' );
    $perf_image_src_md = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-md' );
    $perf_image_src_lg = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-lg' );

    if( $perf_image_id && $active_preload ){
    ?>
        <link rel="preload" as="image" href="<?php echo $perf_image_src_sm[0]; ?>" media="(max-width: 52em)">
        <link rel="preload" as="image" href="<?php echo $perf_image_src_md[0]; ?>" media="(min-width: 52em) and (max-width: 64em)">
        <link rel="preload" as="image" href="<?php echo $perf_image_src_lg[0]; ?>" media="(min-width: 64em)">
    <?php
    }

    if( is_page_template("page-templates/template-front.php") && $active_preload ){
        global $post;

        $sub_sections = perf_get_field("perf_above_fold_sub_section", $post->ID);
        if( is_array($sub_sections) && count($sub_sections) > 0 ){
            foreach( $sub_sections as $box ){
            ?>
                <link rel="preload" as="image" href="<?php echo $box['image']['sizes']['light-bold-hero-md']; ?>" media="(min-width: 52em)">
            <?php
            }
        }

        if( light_bold_flickity_detection( $post->ID ) ){
        ?>
            <link rel="preload" as="script" href="<?php echo get_template_directory_uri(); ?>/inc/3rd-party/flickity/flickity.min.js">
        <?php  
        }
    }

    $logo_sm = perf_get_field("perf_log_sm","option");
    $logo_md = perf_get_field("perf_log_md","option");
    $logo_lg = perf_get_field("perf_log_lg","option");

    if( $active_preload && $logo_sm ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_sm","option"); ?>" media="(max-width: 1200px)">
    <?php
    }

    if( $active_preload && $logo_md ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_md","option"); ?>" media="(min-width: 1200px) and (max-width: 1650px)">
    <?php
    }

    if( $active_preload && $logo_lg ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_lg","option"); ?>" media="(min-width: 1650px)">
    <?php
    }

    if( $active_preload ){
    ?>
        <link rel="preload" href="<?php echo get_template_directory_uri(); ?>/inc/3rd-party/font-awesome/fontawesome.svg">
    <?php
    }

    
}

/*
* More preload added by user
*/
add_action( 'light_bold_head_open', 'perf_more_preload' );
function perf_more_preload() {
    if( perf_get_field("perf_preload_active","option") && !empty( perf_get_field("perf_add_preload","option") ) ){
        echo perf_get_field("perf_add_preload","option");
    }
}


/*
* Critical mobile fix
*/
add_action( 'light_bold_mobile_styles', 'perf_critical_mobile_fix' );
function perf_critical_mobile_fix() {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
    
        $mobile_fix = '
            .small-p, .comment-meta, .textwidget {
                font-size: 16px;
            }

            .button-row{
                display: flex;
                display: -ms-flexbox;
                align-items: stretch;
            }

            .button-row button{
              border-right: 1px solid #403e3e;
            }

            .button-row button.button--previous{
              border-left: 1px solid #403e3e;
            }

            .perf-main-hero { box-sizing: border-box; }

            .is-hidden .carousel-cell{
                display: none;
            }

            .is-hidden .carousel-cell:first-child{
                display: block;
            }
        ';

        echo light_bold_compress( $mobile_fix );
    }
}

/*
* Critical md  fix
*/
add_action( 'light_bold_md_styles', 'perf_critical_md_fix' );
function perf_critical_md_fix() {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        
        $md_fix = '
            .h0-responsive { font-size: 6vw; }
        ';
        
        echo light_bold_compress( $md_fix );
    }
}

/*
* Critical lg  fix
*/
//add_action( 'light_bold_lg_styles', 'perf_critical_lg_fix' );
function perf_critical_lg_fix() {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        
        $lg_fix = '
            #primary-menu a { min-height: 8.33333vh; }
        ';

        echo light_bold_compress( $lg_fix );
    }
}

/*
* Critical 1200  fix
*/
add_action( 'light_bold_1200_styles', 'perf_critical_1200_fix' );
function perf_critical_1200_fix() {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        $fix_1200 = '
            .main-header_container,
            .site-logo {
                display: flex;
                align-items: center;
                display: -ms-flexbox; 
                -ms-flex-align: center;
            }

            nav-container .sub-menu {
                display: none; /* Fix fout on page load */
            }

            .nav-container{transform: translateX(0);}

            .nav-container.multi_level {
                margin-top: 225px;
            }

            .nav-container.multi_level .menu__breadcrumbs{
                top: -75px;
            }
        ';
        echo light_bold_compress( $fix_1200 );
    }
}

/*
* Critical 96em fix
* 1650px
*/
add_action( 'light_bold_96em_styles', 'perf_critical_96em_fix' );
function perf_critical_96em_fix() {
    if( !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        
        $fix_96em = '
            .h0-responsive { font-size: 5.76rem; }

            .nav-container.multi_level {
                margin-top: 275px;
            }
        ';

        echo light_bold_compress( $fix_96em );
    }
}

/*
* Critical admin bar
*/
add_action( 'light_bold_mobile_styles', 'perf_critical_admin' );
function perf_critical_admin() {
    if ( is_user_logged_in() && !perf_on_page_css_optimisation() && perf_get_field("perf_css_optimisation_active","option") && !is_admin() ){
        include_once( "critical/critical-admin.min.css" );
    }
}

add_action( 'light_bold_mobile_styles', 'perf_default_hero' );
function perf_default_hero() {

    $perf_image_id = light_bold_select_hero_image();
    
    if( $perf_image_id ){
        $path = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-placeholder' );
        $type = pathinfo($path[0], PATHINFO_EXTENSION);
        $data = light_bold_get_response($path[0]);
        $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

        $perf_sm_hero = '
            .bg-default{
                background-image: url(' . $base64 . ');
            }
        ';

        echo light_bold_compress( $perf_sm_hero );
    }
    
}

//add_action('init', 'perf_clean_contact_form_7');
function perf_clean_contact_form_7(){
    add_filter( 'wpcf7_load_js', '__return_false' );
    add_filter( 'wpcf7_load_css', '__return_false' );
}
