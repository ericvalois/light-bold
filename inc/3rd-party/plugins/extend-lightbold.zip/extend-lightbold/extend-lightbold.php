<?php
/*
 *  Plugin Name:       Extend Light & Bold 
 *  Plugin URI:        https://ttfb.io/
 *  Description:       Simple plugin to extend Light & Bold theme
 *  Version:           1.1.3
 *  Author:            TTFB
 *  Author URI:        https://ttfb.io/
 *  Text Domain:       perf
 *  Domain Path:       /languages
 */
$current_theme = get_option( 'stylesheet' );
if( $current_theme !== 'light-bold' && $current_theme !== 'light-bold-child' ){
    return false;
}

/**
 * Helper functions
 */
require 'helper.php';

/**
 * Lazy Load
 */
require 'lazyload.php';

/**
 * Load ACF options pages and minor behavior fix
 */
require 'acf-extra.php';

/**
 * Load ACF Meta box
 */
require 'acf-meta-box.php';

/**
 * WordPress cleanup
 */
require 'clean.php';

/**
 * Tinymce Styling
 */
require 'extend-tinymce.php';

/**
 * Custom Dynamic Styles
 */
require 'custom-styles.php';


/*
* Critical CSS
*/
add_action('light_bold_mobile_styles','perf_critical_css', 5);
function perf_critical_css()
{
    if( !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_critical_css_active","option") ) && !is_admin() ){
        echo '/* Critical CSS */ ';

        if( is_page_template("page-templates/template-front.php") ){

            global $post;

            if( light_bold_flickity_detection( $post->ID ) ){
                include_once( "critical/home-with-slider.min.css" );
               
            }else{
                include_once( "critical/home.min.css" );
            }

        }elseif( is_page_template("page-templates/template-contact.php") ){
            include_once( "critical/contact.min.css" );
        }elseif( is_archive() || is_home() || is_search() ){
            include_once( "critical/archive.min.css" );
        }elseif( is_single() ){
            include_once( "critical/single.min.css" );
        }else{
            include_once( "critical/page.min.css" );
        }

        echo '/* End Critical CSS */ ';
    }

}

/**
 * Light & Bold Inline JS Hook
 */
add_action("wp_footer","perf_custom_js", 99);
function perf_custom_js(){
  echo '<script>';

  do_action('light_bold_footer_scripts');

  echo '</script>';
}


/*
* Defer scripts when it's possible
*/
add_action( 'wp_print_scripts', 'perf_defer_scripts' );
add_action( 'wp_footer', 'perf_defer_scripts' );
function perf_defer_scripts() {
    if( !perf_on_page_js_optimisation() && !empty( perf_get_field('perf_js_optimisation_active', 'option') ) && !is_admin() ){
        $enqueued_scripts = get_enqueued_scripts();
        $to_defer = array();

        if( !empty( $enqueued_scripts ) ){
            foreach ($enqueued_scripts as $key => $script) {
                
                // If no dependencies
                if( empty( $script->deps ) ){
                    wp_dequeue_script( $script->handle );
                    $to_defer[] = $script->src;
                }
            }
        }

        add_action( 'wp_footer', function() use( $to_defer ) {
            foreach( $to_defer as $key => $script ): 
                echo '<script type="text/javascript" defer src="'.$script.'"></script>' . PHP_EOL;
            endforeach; 
            
        }, 20 );
    }
}

/*
* Async all stylsheets with loadcss.js
*/
add_action('wp_print_styles', function() {
    if ( ! doing_action( 'wp_head' ) ) { // ensure we are on head
      return;
    }

    // Variables
    global $wp_scripts, $wp_styles;
    //$exluded_scripts = array("jquery-core","jquery-migrate","jquery-ui-core","jquery");
    $exluded_styles = array("admin-bar");
    $queued_styles  = $wp_styles->queue;

    // Styles
    if( !empty( $queued_styles ) && !perf_on_page_css_optimisation() && !empty( perf_get_field('perf_css_optimisation_active', 'option') ) && !is_admin() ){
        foreach ($wp_styles->queue as $key => $element) {
            if ( !in_array( $element, $exluded_styles ) ) {
                unset( $wp_styles->queue[$key] );
            }
        }
    }

    add_action( 'wp_footer', function() use( $queued_styles, $exluded_styles ) {
      
        global $wp_styles;

        // Styles
        if( !empty( $queued_styles ) && !perf_on_page_css_optimisation() && !empty( perf_get_field('perf_css_optimisation_active', 'option') ) && !is_admin() ){
        ?>
            <script>
                /*! loadCSS. [c]2017 Filament Group, Inc. MIT License */
                !function(a){"use strict";var b=function(b,c,d){function e(a){return h.body?a():void setTimeout(function(){e(a)})}function f(){i.addEventListener&&i.removeEventListener("load",f),i.media=d||"all"}var g,h=a.document,i=h.createElement("link");if(c)g=c;else{var j=(h.body||h.getElementsByTagName("head")[0]).childNodes;g=j[j.length-1]}var k=h.styleSheets;i.rel="stylesheet",i.href=b,i.media="only x",e(function(){g.parentNode.insertBefore(i,c?g:g.nextSibling)});var l=function(a){for(var b=i.href,c=k.length;c--;)if(k[c].href===b)return a();setTimeout(function(){l(a)})};return i.addEventListener&&i.addEventListener("load",f),i.onloadcssdefined=l,l(f),i};"undefined"!=typeof exports?exports.loadCSS=b:a.loadCSS=b}("undefined"!=typeof global?global:this);
                /*! Load stylesheet async */
                <?php foreach( $queued_styles as $key => $stylesheet ): ?>
                    <?php if ( !in_array( $stylesheet, $exluded_styles ) ): ?> 
                        loadCSS( "<?php echo $wp_styles->registered[$stylesheet]->src; ?>" );
                    <?php endif; ?> 
                <?php endforeach; ?>

            </script>
            <script></script><!-- Fix IE and Edge bug with loadcss -->
        <?php
        }

    }, 10 );

  }, 0);

/*
* Preload
*/
add_action( 'light_bold_head_open', 'perf_preload' );
function perf_preload() {
    $active_preload = perf_get_field("perf_preload_active","option");
    

    $perf_image_id = light_bold_select_hero_image();
    $perf_image_src_sm = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-sm' );
    $perf_image_src_md = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-md' );
    $perf_image_src_lg = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-lg' );

    if( $perf_image_id && $active_preload ){
    ?>
        <link rel="preload" as="image" href="<?php echo $perf_image_src_sm[0]; ?>" media="(max-width: 52em)">
        <link rel="preload" as="image" href="<?php echo $perf_image_src_md[0]; ?>" media="(min-width: 52em) and (max-width: 64em)">
        <link rel="preload" as="image" href="<?php echo $perf_image_src_lg[0]; ?>" media="(min-width: 64em)">
    <?php
    }

    if( is_page_template("page-templates/template-front.php") && $active_preload ){
        global $post;

        $sub_sections = perf_get_field("perf_sub_section", $post->ID);
        if( is_array($sub_sections) && count($sub_sections) > 0 ){
            foreach( $sub_sections as $box ){
            ?>
                <link rel="preload" as="image" href="<?php echo $box['box']['image']['sizes']['light-bold-hero-md']; ?>" media="(min-width: 52em)">
            <?php
            }
        }

        if( light_bold_flickity_detection( $post->ID ) ){
        ?>
            <link rel="preload" as="script" href="<?php echo get_template_directory_uri(); ?>/inc/3rd-party/flickity/flickity.min.js">
        <?php  
        }
    }

    $logo_sm = perf_get_field("perf_log_sm","option");
    $logo_md = perf_get_field("perf_log_md","option");
    $logo_lg = perf_get_field("perf_log_lg","option");

    if( $active_preload && $logo_sm ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_sm","option"); ?>" media="(max-width: 1200px)">
    <?php
    }

    if( $active_preload && $logo_md ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_md","option"); ?>" media="(min-width: 1200px) and (max-width: 1650px)">
    <?php
    }

    if( $active_preload && $logo_lg ){
    ?>
        <link rel="preload" as="image" href="<?php echo perf_get_field("perf_log_lg","option"); ?>" media="(min-width: 1650px)">
    <?php
    }

    if( $active_preload ){
    ?>
        <link rel="preload" as="fetch" href="<?php echo get_template_directory_uri(); ?>/inc/3rd-party/font-awesome/fontawesome.svg">
    <?php
    }

    
}

/*
* More preload added by user
*/
add_action( 'light_bold_head_open', 'perf_more_preload' );
function perf_more_preload() {
    if( !empty( perf_get_field("perf_preload_active","option") ) && !empty( perf_get_field("perf_add_preload","option") ) ){
        echo perf_get_field("perf_add_preload","option");
    }
}


/*
* Critical mobile fix
*/
add_action( 'light_bold_mobile_styles', 'perf_critical_mobile_fix' );
function perf_critical_mobile_fix() {
    if( !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_css_optimisation_active","option") ) && !is_admin() ){
    
        $mobile_fix = '
            .small-p, .comment-meta, .textwidget {
                font-size: 16px;
            }

            .button-row{
                display: flex;
                display: -ms-flexbox;
                align-items: stretch;
            }

            .button-row button{
              border-right: 1px solid #403e3e;
            }

            .button-row button.button--previous{
              border-left: 1px solid #403e3e;
            }

            .perf-main-hero { box-sizing: border-box; }

            .is-hidden .carousel-cell{
                display: none;
            }

            .is-hidden .carousel-cell:first-child{
                display: block;
            }
        ';

        echo light_bold_compress( $mobile_fix );
    }
}

/*
* Critical md  fix
*/
add_action( 'light_bold_md_styles', 'perf_critical_md_fix' );
function perf_critical_md_fix() {
    if( !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_css_optimisation_active","option") ) && !is_admin() ){
        
        $md_fix = '
            .h0-responsive { font-size: 6vw; }
        ';
        
        echo light_bold_compress( $md_fix );
    }
}

/*
* Critical 1200  fix
*/
add_action( 'light_bold_1200_styles', 'perf_critical_1200_fix' );
function perf_critical_1200_fix() {
    if( !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_css_optimisation_active","option") ) && !is_admin() ){
        $fix_1200 = '
            .main-header_container,
            .site-logo {
                display: flex;
                align-items: center;
                display: -ms-flexbox; 
                -ms-flex-align: center;
            }

            nav-container .sub-menu {
                display: none; /* Fix fout on page load */
            }

            .nav-container{transform: translateX(0);}

            .nav-container.multi_level {
                margin-top: 225px;
            }

            .nav-container.multi_level .menu__breadcrumbs{
                top: -75px;
            }
        ';
        echo light_bold_compress( $fix_1200 );
    }
}

/*
* Critical 96em fix
* 1650px
*/
add_action( 'light_bold_96em_styles', 'perf_critical_96em_fix' );
function perf_critical_96em_fix() {
    if( !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_css_optimisation_active","option") ) && !is_admin() ){
        
        $fix_96em = '
            .h0-responsive { font-size: 5.76rem; }

            .nav-container.multi_level {
                margin-top: 275px;
            }
        ';

        echo light_bold_compress( $fix_96em );
    }
}

/*
* Critical admin bar
*/
add_action( 'light_bold_mobile_styles', 'perf_critical_admin' );
function perf_critical_admin() {
    if ( is_user_logged_in() && !perf_on_page_css_optimisation() && !empty( perf_get_field("perf_css_optimisation_active","option") ) && !is_admin() ){
        include_once( "critical/critical-admin.min.css" );
    }
}

/*
* Inline default hero image for better perceved speed
*/
add_action( 'light_bold_mobile_styles', 'perf_default_hero' );
function perf_default_hero() {

    if( is_page_template("page-templates/template-front.php") ){
        $front_hero = get_field("perf_front_hero");
        if( !empty( $front_hero ) ){
            $perf_image_id = $front_hero['image'];
        }
    }else{
        $perf_image_id = light_bold_select_hero_image();
    }
    
    if( $perf_image_id ){
        $path = wp_get_attachment_image_src( $perf_image_id, 'light-bold-hero-placeholder' );
        $type = pathinfo($path[0], PATHINFO_EXTENSION);
        $data = light_bold_get_response($path[0]);
        $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

        $perf_sm_hero = '
            .bg-default{
                background-image: url(' . $base64 . ');
            }
        ';

        echo light_bold_compress( $perf_sm_hero );
    }
    
}

/*
* Disable contact form 7 scripts and styles
*/
add_action('init', 'perf_clean_contact_form_7');
function perf_clean_contact_form_7(){
    add_filter( 'wpcf7_load_js', '__return_false' );
    add_filter( 'wpcf7_load_css', '__return_false' );
}

/*
* Social share filter
*/
add_filter( "the_content", "perf_add_social_share" );
function perf_add_social_share($content){

    global $post;

    $perf_on_page_share_disabled = perf_get_field('perf_on_page_share_disabled', $post->ID);
    $perf_disable_social_share = perf_get_field("perf_disable_social_share","option");

    if( empty( $perf_disable_social_share ) && empty( $perf_on_page_share_disabled ) && ( !is_page_template("page-templates/template-front.php") || !is_page_template("page-templates/template-contact.php") )  ):


    $content .= '<div class="clearfix"></div><h5 class="mb1 mt3 hide-prin">' . esc_html__("Share this","light-bold") . '</h5>';

    $content .= '<div id="social_widget" class="clearfix mb2 hide-print">';
        $content .= '<div class="left mb1 mr1">';
            $content .= '<a target="_blank" href="http://www.facebook.com/sharer.php?u=' . get_permalink() . '&t=' . urlencode( get_the_title() ) . '" class="flex flex-center social_share align-middle"><svg class="mx-auto fa fa-facebook"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-facebook"></use></svg></a>';
        $content .= '</div>';

        $content .= '<div class="left mb1 mr1">';
            $content .= '<a target="_blank" href="http://twitter.com/home?status=' . urlencode( get_the_title() ) . '+' . get_permalink() . '" class="flex flex-center  social_share"><svg class="mx-auto fa fa-twitter"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-twitter"></use></svg></a>';
        $content .= '</div>';

        $content .= '<div class="left mb1 mr1">';
            $content .= '<a target="_blank" href="https://plus.google.com/share?url=' . get_permalink() . '" class="flex flex-center social_share"><svg class="mx-auto fa fa-google-plus"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-google-plus"></use></svg></a>';
        $content .= '</div>';

        $content .= '<div class="left mb1 mr1">';
            $content .= '<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=' . get_permalink() . '&title=' . urlencode( get_the_title() ) . '" class="flex flex-center  social_share"><svg class="mx-auto fa fa-linkedin"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-linkedin"></use></svg></a>';
        $content .= '</div>';

        $content .= '<div class="left mr1">';
            $pinterest_link = "javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','https://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());";
            $content .= '<a target="_blank" href="'. $pinterest_link .'" class="flex flex-center  social_share"><svg class="mx-auto fa fa-pinterest"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#fa-pinterest"></use></svg></a>';
        $content .= '</div>';
    $content .= '</div>';


    
    endif;

	return $content;
}


/**
 * Load fontawesome sprite ASYNC
 */
add_action("light_bold_footer_scripts","perf_call_sprite_fontawesome");
function perf_call_sprite_fontawesome(){
    ?>
    /* Get fontawesome.svg */ 
    var ajax = new XMLHttpRequest();
    ajax.open("GET", "<?php echo get_template_directory_uri(); ?>/inc/3rd-party/font-awesome/fontawesome.svg", true);
    ajax.send();
    ajax.onload = function(e) {
      var div = document.createElement("div");
      div.innerHTML = ajax.responseText;
      document.body.insertBefore(div, document.body.childNodes[0]);
    }
    <?php
}

/**
 * Remove novalidate from comment form
 */
add_action( 'wp_footer', 'perf_enable_comment_form_validation' );
function perf_enable_comment_form_validation() {
    if ( (!is_admin()) && is_singular() && comments_open() && get_option('thread_comments') && current_theme_supports( 'html5' ) && !is_page_template("page-templates/template-front.php") )  {
        echo '<script>document.getElementById("commentform").removeAttribute("novalidate");</script>' . PHP_EOL;
    }
}